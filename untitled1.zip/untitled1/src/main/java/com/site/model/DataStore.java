package com.site.model;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.annotation.PostConstruct;
import javax.faces.bean.SessionScoped;

/**
 * Created by sergii on 19.01.17.
 */
@ManagedBean
@SessionScoped
public class DataStore implements Serializable {

  private static final long serialVersionUID = -2868321644532814617L;
  private List<String> users;

  @PostConstruct
  private void insertDemoData(){
    users = new LinkedList<>();
    users.add("User1");
    users.add("User2");
    users.add("User3");
    users.add("User4");
    users.add("User5");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User6");
    users.add("User7");
    users.add("User8");
    System.out.println(users);
  }


  public List<String> getUsers() {
    return users;
  }
}
