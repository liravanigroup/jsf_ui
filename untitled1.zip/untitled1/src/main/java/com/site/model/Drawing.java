package com.site.model;

/**
 * Created by sergii on 19.01.17.
 */
public class Drawing {

  private String name;

  private String width;

  private String height;

  public String getName() {
    return name;
  }

  public void setName(final String name) {
    this.name = name;
  }

  public String getWidth() {
    return width;
  }

  public void setWidth(final String width) {
    this.width = width;
  }

  public String getHeight() {
    return height;
  }

  public void setHeight(final String height) {
    this.height = height;
  }
}
